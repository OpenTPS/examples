"""
Example Title
=============

This is an example script that demonstrates XYZ.
"""
print(2+1)
